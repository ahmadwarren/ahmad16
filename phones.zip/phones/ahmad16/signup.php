 
    
<!----------------- my navigation bar -->
<?php 
include_once 'permanent/header.php';
?>
<section>

         <form action="includes/signup.inc.php" class="login" method="post" style="height:auto;margin:auto;text-align:center;">
         <a href="#"class="start">Get Started</a><br>
         <h2>Remplissez d'abord!!!</h2>
         <input type="text"placeholder="name"name="name" >
          <input type="email"placeholder="email or number"name="email" >
          <input type="text"placeholder="user name"name="uid" >
          <input type="password" placeholder="passcode*"name="pwd">
          <input type="password" placeholder="comfirm passcode*"name="pwdrep">
         <div class="bt" style="display: inline-flex;text-align: center;">
           <input type="submit"name="submit" value="create"class="button"style="background-color: var(--main-color-);  color: #fff;">
          <input type="button" value="login"class="button" action="index.php">
         </div> </form> 
        </section>
<?php 
include_once 'permanent/footer.php';
?>

