<?php 
include_once 'permanent/header.php';
?>

 
  <div class="produit">
    <ul>
        <li><a href="#routeur">routeur</a> </li>
        <li><a href="#">modem</a> </li>
       <li><a href=""> switch</a></li>
       <li><a href="">cable</a> </li>
       <li><a href=""> Prise reseau</a></li>
       <li><a href=""> Outils</a></li>
    </ul>
</div>
<section>
  

    <div class="row2">
    <div class="container">


        <div class="flex01">
            <div class="user-icon"></div>
            <div class="user-name"><h2>Routeur</h2></div>

<!-- MY SLIDE -->

            <div class="posted-picture">
                <div class="slideshow-container">

                    <div class="mySlides fade">
                      <div class="numbertext">1 / 4</div>
                      <img src="6.jpg" style="width:100%;height: 200px;">
                      <div class="text">Caption Text</div>
                    </div>
                    
                    <div class="mySlides fade">
                      <div class="numbertext">2 / 3</div>
                      <img src="1.jpg" style="width:100%;height: 200px;">
                      <div class="text">Caption Two</div>
                    </div>
                    
                    <div class="mySlides fade">
                      <div class="numbertext">3 / 4</div>
                      <img src="4.jpg" style="width:100%;height: 200px;">
                      <div class="text">Caption Three</div>
                    </div>
                    <div class="mySlides fade">
                        <div class="numbertext">4 / 4</div>
                        <img src="4.jpg" style="width:100%;height: 200px;">
                        <div class="text">Caption Three</div>
                      </div>
                    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                    <a class="next" onclick="plusSlides(1)">&#10095;</a>
                    
                    </div>
                    <br>
                
                    
             </div> 
            <div class="description">
                <p>le routeur qui peut servir plus de 50 appareils!!</p>
                <h4>12:33  30/décembre/2021</h4>

             </div>
            <div class="time-posted"> 
                <button class="btn" onclick="alert('SVP il faut d_abord créer un compte');"><i>Buy </i> 
                    <svg xmlns="http://www.w3.org/2000/svg"fill="#fff" viewBox="0 0 576 512"><path d="M504.717 320H211.572l6.545 32h268.418c15.401 0 26.816 14.301 23.403 29.319l-5.517 24.276C523.112 414.668 536 433.828 536 456c0 31.202-25.519 56.444-56.824 55.994-29.823-.429-54.35-24.631-55.155-54.447-.44-16.287 6.085-31.049 16.803-41.548H231.176C241.553 426.165 248 440.326 248 456c0 31.813-26.528 57.431-58.67 55.938-28.54-1.325-51.751-24.385-53.251-52.917-1.158-22.034 10.436-41.455 28.051-51.586L93.883 64H24C10.745 64 0 53.255 0 40V24C0 10.745 10.745 0 24 0h102.529c11.401 0 21.228 8.021 23.513 19.19L159.208 64H551.99c15.401 0 26.816 14.301 23.403 29.319l-47.273 208C525.637 312.246 515.923 320 504.717 320zM408 168h-48v-40c0-8.837-7.163-16-16-16h-16c-8.837 0-16 7.163-16 16v40h-48c-8.837 0-16 7.163-16 16v16c0 8.837 7.163 16 16 16h48v40c0 8.837 7.163 16 16 16h16c8.837 0 16-7.163 16-16v-40h48c8.837 0 16-7.163 16-16v-16c0-8.837-7.163-16-16-16z"/></svg></button>
                <p style="display: inline;">à 200 000 <span>fbu</span><br>
                    <s>320 000 fbu</s> </p>
            </div>
          
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
            <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex03">
            <div class="user-icon"></div>
            <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex04">
            <div class="user-icon"></div>
            <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div>
    <br><br>
    <div class="container">
    
        <div class="flex01">
            <div class="user-icon"></div>
            <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
         <div class="user-icon"></div>
         <div class="user-name"></div>
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex03">
            <div class="user-icon"></div>
        <div class="user-name"></div>
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div><br><br>
    <div class="container">
    
        <div class="flex01">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex03">
          <div class="user-name"></div>
          <div class="user-icon"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
    
    </div><br>
    
    <div class="container">
    
        <div class="flex01">
         
          <div class="user-icon"></div>
           <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
        <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex03">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div>

    <br>
    <div class="container">
    
        <div class="flex01">
         
          <div class="user-icon"></div>
           <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
        <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex03">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div><br>


    <div class="container">
    
        <div class="flex01">
         
          <div class="user-icon"></div>
           <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
        <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex03">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div><br>



    <div class="container">
    
        <div class="flex01">
         
          <div class="user-icon"></div>
           <div class="user-name"></div>
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
        <div class="flex02">
            <div class="user-icon"></div>
        <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex03">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
        <div class="posted-picture"></div>
        <div class="description"></div>
        <div class="time-posted"></div>
    </div>
        <div class="flex04">
            <div class="user-icon"></div>
          <div class="user-name"></div>
    
            <div class="posted-picture"></div>
            <div class="description"></div>
            <div class="time-posted"></div>
        </div>
    
    </div>
</div>
    <br><br><br><br><br>
</section>














<?php 
include_once 'permanent/footer.php';
?>


<script src="slide.js" lang="javascript"></script>
</body>
</html>