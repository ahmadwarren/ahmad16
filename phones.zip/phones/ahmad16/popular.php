<!----------------- my navigation bar -->
<?php 
include_once 'permanent/header.php';
?>


<section style="overflow-x: hidden;">
       
<div id="programme">
    <div class="text" style="height: 95vh;width: 100%;">
      <div class="event-container">
        <div class="agenda-generale">
          <h1>MOST POPULAR!!</h1>
        </div>
       

         <div class="event">
        <div class="event-left">
         <div class="event date">
           <div class="date">8</div>
           <div class="mois">nov </div>

                 </div>
                 </div>

         <div class="event-right">
  <h3 class="event-title">some title here</h3>

  <div class="event-description">
    <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;top:100px;">lieu de deroulement</h3>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid, corrupti facere quae 
    aliquam laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus asperiores, dolor 
    animi architecto vero possimus?

  </div>
<div class="event-timing">
<img src="" alt="" /> 10:00 am
</div>
</div>
</div>

<div class="event">
<div class="event-left">
<div class="event date">
<div class="date">9</div>
<div class="mois">mar</div>

</div>
</div>

<div class="event-right">
 <h3 class="event-title">some title here</h3>

 <div class="event-description">
  <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;">lieu de deroulement</h3>
   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid, corrupti facere quae
    aliquam laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus asperiores,
     dolor animi architecto vero possimus?

 </div>
<div class="event-timing">
<img src="" alt="" /> 10:00 am
</div>
</div>
</div>
<div class="event">
<div class="event-left">
<div class="event date">
<div class="date">8</div>
<div class="mois">jav</div>

</div>
</div>

<div class="event-right">
 <h3 class="event-title">some title here</h3>

 <div class="event-description">
  <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;">lieu de deroulement</h3>
   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid
   , corrupti facere quae aliquam laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus
    asperiores, dolor animi architecto vero possimus?

 </div>
<div class="event-timing">
<img src="" alt="" /> 10:00 am
</div>
</div>
</div>
<div class="event">
<div class="event-left">
<div class="event date">
<div class="date">4</div>
<div class="mois">nov </div>

</div>
</div>

<div class="event-right">
 <h3 class="event-title">some title here</h3>

 <div class="event-description">
  <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;">lieu de deroulemente</h3>
   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid, corrupti facere quae aliquam 
   laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus asperiores, dolor animi architecto vero possimus?

 </div>
<div class="event-timing">
<img src="" alt="" /> 10:00 am
</div>
</div>
</div>
<div class="event">
<div class="event-left">
<div class="event date">
<div class="date">2</div>
<div class="mois">avr </div>

</div>
</div>

<div class="event-right">
 <h3 class="event-title">some title here</h3>

 <div class="event-description">
  <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;">lieu de deroulement</h3>
   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid, corrupti facere quae 
   aliquam laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus asperiores,
    dolor animi architecto vero possimus?

 </div>
<div class="event-timing">
<img src="" alt="" /> 10:00 am
</div>
</div>
</div>
<div class="event">
<div class="event-left">
<div class="event date">
<div class="date">8</div>
<div class="mois">nov </div>

</div>
</div>

<div class="event-right">
 <h3 class="event-title">some title here</h3>

 <div class="event-description">
  <h3 style="color: darkgoldenrod; margin-left:20px;font-size: 20px;">lieu de deroulemente</h3>
   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sequi quos aliquid,
    corrupti facere quae aliquam laboriosam, dolores perspiciatis cumque nesciunt aperiam assumenda itaque accusamus
     asperiores, dolor animi architecto vero possimus?

 </div>
       <div class="event-timing">
       <img src="" alt="" /> 15:38 am
           </div>
         </div>
         </div>
           </div>
</section>

<!-- le footer  -->
<?php 
include_once 'permanent/footer.php';
?>





</body>
</html>