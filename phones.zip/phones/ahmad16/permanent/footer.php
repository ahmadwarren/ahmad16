

<footer id="about">
    <div class="container">
        <div class="block1">

            <ol class="block1-info">
                <li><a href="#"> nos nouveauté</a></li>
                <li><a href="#"> nos promotion</a></li>
                <li><a href="#"> notre philosophie</a></li>
                <li> <a href="#"> faveur aux clients</a></li>
                <li><a href="#"> conditions d'utilisation</a></li>
            </ol>
        </div>

        <div class="block2">
            <h1>
                notre objectif

            </h1>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis delectus neque unde numquam perspiciatis, quaerat harum quas amet saepe, sed perferendis earum pariatur doloribus ad laudantium at, veniam ex blanditiis.
            </p>
            
        </div>

        <div class="block3">
            <div class="logo-footer">MegaVibes</div>
           <div class="subscribe"> <input type="email" class="subscriber-email" placeholder="put your email">
        <a href="#"  class="subscribe-button">subscribe</a>
        </div>
        <div class="icons">
            <i class="fab fa-facebook"></i>


        </div>
    </div>


    </div>
</footer>





<button onclick="topFunction()" id="myBtn" title="Go to top"><strong>&#187;</strong></button>
<div class="copyright">©AHMAD All right reserved</div>