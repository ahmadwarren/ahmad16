
    
<!----------------- my navigation bar -->
<?php 
include_once 'permanent/header.php';
?>




<!-------------------------- my section of home------------------ -->


<section id="welcome" style="margin-top: 0px;">

<div class="welcome">
   
        <div class="welcome-text">
            <h1>Welcome to your shop</h1>
         
         <form action="signup.php" class="login" method="post">
         <a href="#"class="start">Get Started</a><br>
         <h2>Remplissez d'abord!!!</h2>
          <input type="text"placeholder="email or number" >
          <input type="password" placeholder="passcode*">
         <div class="bt" style="display: inline-flex;text-align: center;">
           <input type="submit"name="submit" value="login"class="button"style="background-color: var(--main-color-);  color: #fff;">
          <a href="signup.php"  value=""class="button" >create</a>
         </div> </form> 

            <!-- mettre un png d' 1 chariot -->
        </div>



        <div class="welcome-slide" style="margin-top: 100px;">
            <div class="slideshow-container"style="max-width:400px">

                <div class="mySlides fade">
                  <div class="numbertext">1 / 4</div>
                  <img src="6.jpg" style="width:100%;height: 400px;">
                  <div class="text">ROUTER</div>
                </div>
                
                <div class="mySlides fade">
                  <div class="numbertext">2 / 3</div>
                  <img src="1.jpg" style="width:100%;height: 400px;">
                  <div class="text">Vue face</div>
                </div>
                
                <div class="mySlides fade">
                  <div class="numbertext">3 / 4</div>
                  <img src="4.jpg" style="width:100%;height: 400px;">
                  <div class="text">Vue profil</div>
                </div>
                <div class="mySlides fade">
                    <div class="numbertext">4 / 4</div>
                    <img src="4.jpg" style="width:100%;height: 400px;">
                    <div class="text">Bien vue boss </div>
                  </div>
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
                
                </div>
                <br>
                
                <div style="text-align:center">
                  <span class="dot" onclick="currentSlide(1)"></span> 
                  <span class="dot" onclick="currentSlide(2)"></span> 
                  <span class="dot" onclick="currentSlide(3)"></span> 
                  <span class="dot" onclick="currentSlide(4)"></span> 
                </div>
        </div>
  
</div>



</section>
<?php 
include_once 'permanent/footer.php';
?>




<script src="slide.js" lang="javascript"></script>

</body>
</html>